import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'models' },
  { path: 'models', loadComponent: () => import('./pages/models').then((m) => m.ModelsPage) },
  { path: 'ask', loadComponent: () => import('./pages/ask').then((m) => m.AskPage) },
  { path: '**', redirectTo: 'models' },
];
