import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header>
      <strong>AI Lab</strong>
      <nav>
        <a routerLink="/models" routerLinkActive="active">1. Models</a>
        <a routerLink="/ask" routerLinkActive="active">2. Ask</a>
        <a routerLink="/tokens" routerLinkActive="active">3. Tokens</a>
        <a routerLink="/chat" routerLinkActive="active">4. Chat</a>
      </nav>
    </header>
    <main><router-outlet /></main>
  `,
  styles: [`
    header { background:#fff; border-bottom:1px solid #e2e8f0; padding:10px 16px; display:flex; gap:16px; align-items:center; flex-wrap:wrap; }
    nav { display:flex; gap:6px; flex-wrap:wrap; }
    nav a { color:#475569; text-decoration:none; padding:4px 10px; border-radius:999px; font-size:.9rem; }
    nav a.active { background:#eef2ff; color:#3730a3; font-weight:600; }
    main { max-width:860px; margin:0 auto; padding:16px; }
  `],
})
export class App {}
