import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'models' },
  { path: 'models', loadComponent: () => import('./pages/models').then((m) => m.ModelsPage) },
  { path: '**', redirectTo: 'models' },
];
