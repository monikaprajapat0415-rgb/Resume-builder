import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header>
      <strong>AI Lab</strong>
      <nav>
        <a routerLink="/models" routerLinkActive="active">1. Models</a>
        <a routerLink="/ask" routerLinkActive="active">2. Ask</a>
        <a routerLink="/tokens" routerLinkActive="active">3. Tokens</a>
        <a routerLink="/chat" routerLinkActive="active">4. Chat</a>
        <a routerLink="/stream" routerLinkActive="active">5. Stream</a>
        <a routerLink="/reliable" routerLinkActive="active">6. Reliable</a>
        <a routerLink="/caching" routerLinkActive="active">7. Caching</a>
        <a routerLink="/documents" routerLinkActive="active">8. Documents</a>
        <a routerLink="/agent" routerLinkActive="active">9. Tools</a>
        <a routerLink="/safe-agent" routerLinkActive="active">10. Safe tools</a>
        <a routerLink="/match" routerLinkActive="active">11. Match</a>
        <a routerLink="/prompt-lab" routerLinkActive="active">12. Prompt lab</a>
        <a routerLink="/rag" routerLinkActive="active">13. Ask docs</a>
        <a routerLink="/search" routerLinkActive="active">14. Search</a>
        <a routerLink="/store" routerLinkActive="active">15. Store</a>
        <a routerLink="/rag-plus" routerLinkActive="active">16. RAG+</a>
        <a routerLink="/agent-loop" routerLinkActive="active">17. Agent loop</a>
        <a routerLink="/team" routerLinkActive="active">18. Team</a>
        <a routerLink="/mcp" routerLinkActive="active">19. MCP</a>
        <a routerLink="/mcp-ask" routerLinkActive="active">20. MCP + Claude</a>
        <a routerLink="/mcp-safe" routerLinkActive="active">21. Safe MCP</a>
        <a routerLink="/evals" routerLinkActive="active">22. Evals</a>
      </nav>
    </header>
    <main><router-outlet /></main>
  `,
  styles: [`
    header { background:#fff; border-bottom:1px solid #e2e8f0; padding:10px 16px; display:flex; gap:16px; align-items:center; flex-wrap:wrap; }
    nav { display:flex; gap:6px; flex-wrap:wrap; }
    nav a { color:#475569; text-decoration:none; padding:4px 10px; border-radius:999px; font-size:.9rem; }
    nav a.active { background:#eef2ff; color:#3730a3; font-weight:600; }
    main { max-width:860px; margin:0 auto; padding:16px; }
  `],
})
export class App {}
