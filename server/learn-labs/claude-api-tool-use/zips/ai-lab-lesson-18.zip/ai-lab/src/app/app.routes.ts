import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'models' },
  { path: 'models', loadComponent: () => import('./pages/models').then((m) => m.ModelsPage) },
  { path: 'ask', loadComponent: () => import('./pages/ask').then((m) => m.AskPage) },
  { path: 'tokens', loadComponent: () => import('./pages/tokens').then((m) => m.TokensPage) },
  { path: 'chat', loadComponent: () => import('./pages/chat').then((m) => m.ChatPage) },
  { path: 'stream', loadComponent: () => import('./pages/stream').then((m) => m.StreamPage) },
  { path: 'reliable', loadComponent: () => import('./pages/reliable').then((m) => m.ReliablePage) },
  { path: 'caching', loadComponent: () => import('./pages/caching').then((m) => m.CachingPage) },
  { path: 'documents', loadComponent: () => import('./pages/documents').then((m) => m.DocumentsPage) },
  { path: 'agent', loadComponent: () => import('./pages/agent').then((m) => m.AgentPage) },
  { path: 'safe-agent', loadComponent: () => import('./pages/safe-agent').then((m) => m.SafeAgentPage) },
  { path: 'match', loadComponent: () => import('./pages/match').then((m) => m.MatchPage) },
  { path: 'prompt-lab', loadComponent: () => import('./pages/prompt-lab').then((m) => m.PromptLabPage) },
  { path: 'rag', loadComponent: () => import('./pages/rag').then((m) => m.RagPage) },
  { path: 'search', loadComponent: () => import('./pages/search').then((m) => m.SearchPage) },
  { path: 'store', loadComponent: () => import('./pages/store').then((m) => m.StorePage) },
  { path: 'rag-plus', loadComponent: () => import('./pages/rag-plus').then((m) => m.RagPlusPage) },
  { path: 'agent-loop', loadComponent: () => import('./pages/agent-loop').then((m) => m.AgentLoopPage) },
  { path: 'team', loadComponent: () => import('./pages/team').then((m) => m.TeamPage) },
  { path: '**', redirectTo: 'models' },
];
