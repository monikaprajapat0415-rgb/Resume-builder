# AI Lab (Angular + Node) - solution after lesson 18 of 25

A small Angular app plus a Node server that talks to the Claude API. Your API key stays on the server and never reaches the browser.

## Run it

1. Install Node.js (version 20 or newer) and run `npm install` in this folder.
2. Copy `.env.example` to `.env` and put your key in `ANTHROPIC_API_KEY`. Never commit `.env`.
3. Terminal 1: `npm run server`   (API on http://localhost:3000)
4. Terminal 2: `npm start`        (Angular on http://localhost:4200)

Open http://localhost:4200. The menu shows one page for every lesson you have completed (18 of 25).

## Layout

- `server/index.js` loads every file in `server/routes/` as an API route.
- `server/claude.js` creates the Claude client from `.env`.
- `src/app/pages/` has one Angular page per lesson.
- `proxy.conf.json` sends `/api` calls from Angular to the server during development.
- `server/rag/` holds the RAG code and the sample documents in `server/rag/docs/`. Files the app writes while running (the vector store, notes, usage log) go to `server/runtime/`.

Model names, features and prices change. Check docs.anthropic.com before you rely on them.
