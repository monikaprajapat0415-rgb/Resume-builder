import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'spam' },
  { path: 'spam', loadComponent: () => import('./pages/spam').then((m) => m.SpamPage) },
  { path: 'vectors', loadComponent: () => import('./pages/vectors').then((m) => m.VectorsPage) },
  { path: 'classifier', loadComponent: () => import('./pages/classifier').then((m) => m.ClassifierPage) },
  { path: 'neural', loadComponent: () => import('./pages/neural').then((m) => m.NeuralPage) },
  { path: 'markov', loadComponent: () => import('./pages/markov').then((m) => m.MarkovPage) },
  { path: 'sampling', loadComponent: () => import('./pages/sampling').then((m) => m.SamplingPage) },
  { path: 'memory', loadComponent: () => import('./pages/memory').then((m) => m.MemoryPage) },
  { path: 'prompt-builder', loadComponent: () => import('./pages/prompt-builder').then((m) => m.PromptBuilderPage) },
  { path: 'chain', loadComponent: () => import('./pages/chain').then((m) => m.ChainPage) },
  { path: 'json-check', loadComponent: () => import('./pages/json-check').then((m) => m.JsonCheckPage) },
  { path: '**', redirectTo: 'spam' },
];
