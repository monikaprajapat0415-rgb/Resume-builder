import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'spam' },
  { path: 'spam', loadComponent: () => import('./pages/spam').then((m) => m.SpamPage) },
  { path: '**', redirectTo: 'spam' },
];
