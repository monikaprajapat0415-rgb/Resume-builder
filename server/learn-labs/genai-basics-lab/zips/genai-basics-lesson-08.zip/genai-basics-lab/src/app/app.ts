import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header>
      <strong>GenAI Basics Lab</strong>
      <nav>
        <a routerLink="/spam" routerLinkActive="active">1. Rules vs learning</a>
        <a routerLink="/vectors" routerLinkActive="active">2. Maths</a>
        <a routerLink="/classifier" routerLinkActive="active">3. Train and test</a>
        <a routerLink="/neural" routerLinkActive="active">4. Neural net</a>
        <a routerLink="/markov" routerLinkActive="active">5. Generator</a>
        <a routerLink="/sampling" routerLinkActive="active">6. Sampling</a>
        <a routerLink="/memory" routerLinkActive="active">7. Model size</a>
        <a routerLink="/prompt-builder" routerLinkActive="active">8. Prompt builder</a>
      </nav>
    </header>
    <main><router-outlet /></main>
  `,
  styles: [`
    header { background:#fff; border-bottom:1px solid #e2e8f0; padding:10px 16px; display:flex; gap:16px; align-items:center; flex-wrap:wrap; }
    nav { display:flex; gap:6px; flex-wrap:wrap; }
    nav a { color:#475569; text-decoration:none; padding:4px 10px; border-radius:999px; font-size:.9rem; }
    nav a.active { background:#eef2ff; color:#3730a3; font-weight:600; }
    main { max-width:860px; margin:0 auto; padding:16px; }
  `],
})
export class App {}
